@echo off
echo FGStatsView Version 1.0
echo This feature has not been implemented yet.
pause
exit