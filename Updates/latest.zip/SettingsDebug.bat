@echo off
:r
cls
echo SettingsDebug
echo.
echo 1) Creative level lookup settings
echo 2) Creative level database
echo 3) Trigger reinstall
echo.
set /p opt=Opt: 
if %opt%==1 goto levellookup
if %opt%==2 goto managecrelvldb
if %opt%==3 goto triggerreinstall
echo No valid option has been selected.
pause
goto r

:levellookup
cls
echo Level lookup settings
echo.
echo 1) Perform level lookup + save levels to cache
echo Once a creative levels details have been downloaded, it´ll be saved to disk so we dont have to ask fallguysdb.info every time for the same creative levels.
echo 2) Perform level lookup, dont save levels to cache
echo fallguysdb.info will be asked every time for the level name.
echo 3) Dont perform level lookups
echo This will only show the level code instead of the level name.
echo 4) Return to main menu
echo.
set /p opt=Opt: 
if %opt%==1 goto setlvl1
if %opt%==2 goto setlvl2
if %opt%==3 goto setlvl3
if %opt%==4 goto r
echo No valid option has been selected.
pause
goto levellookup

:setlvl1
echo working ...
del FGPlayer\disablelvlcache.txt /Q /F
del FGPlayer\disablelvllookup.txt /Q /F
echo Completed. (Ignore error for non-existent files, I was too lazy to add if exist in front of them)
pause
goto r

:setlvl2
echo working ...
echo a>FGPlayer\disablelvlcache.txt /Q /F
del FGPlayer\disablelvllookup.txt /Q /F
echo Completed. (Ignore error for non-existent files, I was too lazy to add if exist in front of them)
pause
goto r

:setlvl3
echo working ...
echo a>FGPlayer\disablelvllookup.txt
del FGPlayer\disablelvlcache.txt /Q /F
echo Completed. (Ignore error for non-existent files, I was too lazy to add if exist in front of them)
pause
goto r

:managecrelvldb
cls
echo Manage creative level database
echo.
echo Creaitve level names are stored under %cd%\MAPS.
echo If you want, you can change the names locally by changing the linked file.
echo For example, if your share code is 1111-1111-1111, you´d have to open the text file CREATIVE-1111-1111-1111.txt and modify the level name inside.
echo If you want to trigger a level name refresh, you can delete the text file which is named after the level´s share code and it should re-download once you play that level again (and havent disabled level lookups / disabled caching)
echo You can also delete ALL CACHED LEVEL NAMES here.
echo.
echo 1) Delete ALL cached level names
echo 2) Return to main menu
set /p opt=Opt: 
if %opt%==1 goto wipelvldb
if %opt%==2 goto r
echo No valid option has been selected.
pause
goto managecrelvldb

:wipelvldb
cls
echo working ...
del MAPS\CREATIVE-*.txt /Q /F
echo completed.
pause
goto r

:triggerreinstall
cls
echo Are you sure you want to trigger a reinstall of FGPlayer? (y/n)
echo This shoudnt get rid of any statistics, but should redownload and replace all script / offline map files.
set /p opt=Opt: 
if %opt%==y goto delver
if %opt%==n goto r
echo No valid option has been selected.
pause
goto triggerreinstall

:delver
cls
echo working ...
del version.txt
echo completed.
echo You may now run the script "Start.bat" or redownload it from GitHub into the same directory (%cd%) to reinstall.
echo Press any key to exit.
pause >NUL
exit