@echo off
set homecddir="%cd%"
echo This script downloads required dependencies licensed under GNU GPL Version 2.0.
echo You can review the license here: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
echo The files will be downloaded from: https://sourceforge.net/projects/gnuwin32/files/coreutils/5.3.0/
echo The files we´re using are: tail.exe (helping with log file extraction) and its DLL file dependencies.
echo We will keep the ZIP-File dependencies saved under %cd%\Dependencies.
echo A full copy of the GNU GPL v2 license will be stored at:
echo %cd%\Dependencies\zipOut.zip\contrib\coreutils\5.3.0\coreutils-5.3.0-src\COPYING
echo Huge thanks to https://fallguysdb.info for providing an API for Creative level lookup!
echo.
:promptconsent
set /p userchoice="Do you want to proceed? (Y/N) "
if /i %userchoice%==Y goto proceed
if /i %userchoice%==N exit
echo Please type Y to agree, N to cancel and confirm with Enter.
goto promptconsent

:proceed
md Dependencies
cd Dependencies
curl --location "https://sourceforge.net/projects/gnuwin32/files/coreutils/5.3.0/coreutils-5.3.0-bin.zip/download" >zipOut.zip
certutil -hashfile zipOut.zip SHA512 | findstr /V ":">hashout.txt
set /p hashoutput=<hashout.txt
if "%hashoutput%"=="7bd1cda9ccd969ea65931c6fca44001722022e3a360f3aecc274648de1b3dc830ac3521a453d8eb8ca74bba92ca4b645a0a66a7368ca202af482b1caca5b2b67" goto hashmatching
echo The downloaded file coreutils-5.3.0-bin.zip does not match the stored hash value.
echo The file has been downloaded via https://sourceforge.net/projects/gnuwin32/files/coreutils/5.3.0/coreutils-5.3.0-bin.zip/download
echo We will keep the file at %cd%\zipOut.zip, so you can verify its contents.
echo Press any key to exit as it is currently not safe to continue.
pause >NUL
exit

:hashmatching
md Zip1
copy zipOut.zip Zip1\
cd Zip1
tar -xf zipOut.zip
copy bin\tail.exe ..\..\
cd ..
rd Zip1 /Q /S
curl --location "https://sourceforge.net/projects/gnuwin32/files/coreutils/5.3.0/coreutils-5.3.0-dep.zip/download" >depOut.zip
certutil -hashfile depOut.zip SHA512 | findstr /V ":">hashout2.txt
set /p hashoutput=<hashout2.txt
if "%hashoutput%"=="c39f5abd1a3792e8b91a8eba2b8ad593e2e4794ca33a30e4d3eb51b9d98a75813cc5765e79e06d5acee7228eb873f2ead1d85618b907a44fa02e60674e0d3810" goto hashmatching2
echo The downloaded file coreutils-5.3.0-dep.zip does not match the stored hash value.
echo The file has been downloaded via https://sourceforge.net/projects/gnuwin32/files/coreutils/5.3.0/coreutils-5.3.0-dep.zip/download
echo We will keep the file at %cd%\depOut.zip, so you can verify its contents.
echo Press any key to exit as it is currently not safe to continue.
pause >NUL
exit

:hashmatching2
md Zip2
copy depOut.zip Zip2\
cd Zip2
tar -xf depOut.zip
copy bin\*.dll ..\..\
cd ..
rd Zip2 /Q /S
echo Installation completed. Press any key to launch.
rem echo Note: You can use the batch script SettingsDebug.bat stored under %cd% to change a few settings / debug FGPlayer.
pause
cd "%homecddir%"
goto :EOF