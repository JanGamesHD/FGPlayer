@echo off
color c
echo FGPlayer (Public Beta v.1.29)
if exist langs\init.txt type langs\init.txt && goto afterinitmsg
echo Please wait. Initializing FGPlayer...
if exist LANG.bat echo Loading LANG.bat file ... && call LANG.bat
if not defined text.readymm set text.readymm=Ready (for matchmaking).
if not defined text.mmconnecting set text.mmconnecting=Connecting to matchmaking ...
if not defined text.mmjoining set text.mmjoining=Joining queue ...
if not defined text.mmwaitingplayers set text.mmwaitingplayers=Joining queue (Waiting for Squad) ...
if not defined text.mmemptystring set text.mmemptystring=Matchmaking Connected!
if not defined text.mmsessionassignment set text.mmsessionassignment=Session Assigned. Waiting for a game server ...
if not defined text.mmcurrentplayers set text.mmcurrentplayers=Queued. Players waiting for a match
if not defined text.mmgameserverstarting set text.mmgameserverstarting=Server starting, please wait ...

if not defined text.connecting set text.connecting=Connecting ...
if not defined text.logingameserver set text.logingameserver=Logging In ... (Waiting for server)
if not defined text.connectedfetchdetails set text.connectedfetchdetails=Connected
if not defined text.connectedshow set text.connectedshow=Show
if not defined text.connectedping set text.connectedping=Ping
if not defined text.connectedpid set text.connectedpid=Player ID
if not defined text.issquadgame set text.issquadgame=SQ

if not defined text.loading_waitmap set text.loading_waitmap=Waiting for Map
if not defined text.loadingmap set text.loadingmap=Loading map ...
if not defined text.loadingmap_known set text.loadingmap_known=Loading Map
if not defined text.loadingmap_done set text.loadingmap_done=Map loaded. Loading map details ...
if not defined text.maploaded_players set text.maploaded_players=Players
if not defined text.maploaded_playersleft set text.maploaded_playersleft=Remain
if not defined text.maploaded_map set text.maploaded_map=Map
if not defined text.mapload_waitplayers set text.mapload_waitplayers=Waiting for players ...

if not defined text.platform.steam set text.platform.steam=PC-Steam
if not defined text.platform.epic set text.platform.epic=PC-Epic
if not defined text.platform.ps4 set text.platform.ps4=PS4
if not defined text.platform.ps5 set text.platform.ps5=PS5
if not defined text.platform.xsx set text.platform.xsx=XBOX X/S
if not defined text.platform.xb1 set text.platform.xb1=XBOX ONE
if not defined text.platform.switch set text.platform.switch=SWITCH
if not defined text.platform.iosega set text.platform.iosega=iOS
if not defined text.platform.androidega set text.platform.androidega=ADR
if not defined text.platform.bots set text.platform.bots=BOTS
if not defined text.platform.players set text.platform.players=Players
if not defined text.platform.map set text.platform.map=Map

if not defined text.pregame.wait set text.pregame.wait=Waiting ...
if not defined text.pregame.countdown set text.pregame.countdown=3... 2... 1...
if not defined text.pregame.roundprefix set text.pregame.roundprefix=R
if not defined text.pregame.players set text.pregame.players=Players

if not defined text.ingame.time set text.ingame.time=TIME
if not defined text.ingame.qualifiedownprefix set text.ingame.qualifiedownprefix=Q
if not defined text.ingame.roundprefix set text.ingame.roundprefix=R
if not defined text.ingame.totalqualified set text.ingame.totalqualified=Qualified
if not defined text.ingame.totaleliminated set text.ingame.totaleliminated=Eliminated
if not defined text.ingame.owneliminated set text.ingame.owneliminated=(Eliminated)

if not defined text.roundover.round set text.roundover.round=Round
if not defined text.roundover.over set text.roundover.over=Over!
if not defined text.roundover.timetook set text.roundover.timetook=Took
if not defined text.roundover.map set text.roundover.map=Map
if not defined text.roundover.qualified set text.roundover.qualified=Qualified
if not defined text.roundover.youwon set text.roundover.youwon=You Won!
if not defined text.roundover.youeliminated set text.roundover.youeliminated=You have been eliminated. (Just now)

if not defined text.victory.victoryscreen set text.victory.victoryscreen=Victory screen
if not defined text.victory.have set text.victory.have=You have
if not defined text.victory.have2 set text.victory.have2=Wins in Fall Guys
if not defined text.victory.qualified set text.victory.qualified=Qualified in Final Round
if not defined text.victory.lost set text.victory.lost=You lost

if not defined text.explore.waitmm set text.explore.waitmm=Waiting for matchmaking ...

if not defined text.leveldb.lookup set text.leveldb.lookup=Looking up level
if not defined text.leveldb.powershell set text.leveldb.powershell=Extracting level ...

if not defined text.start.connecting set text.start.connecting=Connecting ...
if not defined text.start.loggingin set text.start.loggingin=Logging In ...
if not defined text.start.loggingincatapult set text.start.loggingincatapult=Logging into Catapult ...
if not defined text.start.checkeula set text.start.checkeula=Checking for EULA ...
if not defined text.start.loggingfg set text.start.loggingfg=Logging Into Fall Guys ...
if not defined text.start.contentdl set text.start.contentdl=Downloading Content Update ...
if not defined text.start.contentdldone set text.start.contentdldone=Download completed!
if not defined text.start.connectgateway set text.start.connectgateway=Connecting to Gateway server ...
if not defined text.start.logginggateway set text.start.logginggateway=Logging Into Gateway server ...
if not defined text.start.loadgame set text.start.loadgame=Loading game ...
if not defined text.start.claimrewards set text.start.claimrewards=Claiming all rewards ...
if not defined text.start.claimrewards_done set text.start.claimrewards_done=Claimed all rewards.
if not defined text.start.achivements set text.start.achivements=Receiving catapult achivements ...
if not defined text.start.waitgameservices set text.start.waitgameservices=Waiting for game services ...
if not defined text.start.gameservices_done set text.start.gameservices_done=Game Services loaded.
if not defined text.start.contentload set text.start.contentload=Loading content update ... 
if not defined text.start.contentload_done set text.start.contentload_done=Content update loaded!
if not defined text.start.loggedincataput set text.start.loggedincataput=Logged into Catapult!
if not defined text.start.createparty set text.start.createparty=Creating party ...
for /f "delims=" %%a in ('echo prompt $E^| cmd') do set "ESC=%%a"
echo %ESC%[?25l
:afterinitmsg
set magicnumber=30
rem Here you can specify the log file location. The default is %userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log
rem You should only change this, if you want to run this script on a different device than you´re running Fall Guys on.
rem For example, you could run this script on a laptop, while playing Fall Guys on your main PC.
rem In that case, you can mount a network drive and change its location here accordingly
set logfile=%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log
rem The new ingame system has unlike the regular ingame system the addition, of setting checkpoints after every action ingame,
rem but with the cost of more I/O to disk. (I thought this would improve performance for some devices, but I coudnt verify that yet.
if not defined usenewingamesystem set usenewingamesystem=0
rem If performclip is defined (to 1), the script will automatically copy the map details to the clipboard on every map.
if not defined performclip set performclip=0
rem The lonely ingame system only checks for time updates, round over, main menu and round over details.
rem Once found, the round is over, the script will perform the actions from the regular ingame system once, to fetch the map details before switching
rem to the Round Over state. This should be used on slower devices. 
if not defined lonelyingamesystem set lonelyingamesystem=0
rem If you want to avoid polling the Fall Guys log without break in the main menu, you can uncomment
rem this option below, where the value contains the time in seconds how often the log file should be checked for matchmaking.
rem set genwaitarearest=1
rem If your device takes too long to fetch the player device information, you can skip this by uncommenting this below.
rem set skipplayernums=1
if %usenewingamesystem%==1 echo WARNING: Test 'usenewingamesystem' active. Please report any bugs found.
setlocal enabledelayedexpansion
if not exist STATS\ goto createstats
:afterstatscreation
if not exist STATS\ALLTIME\UGC2MAP\ md STATS\ALLTIME\UGC2MAP\
set sessiondate=%date:/=%
set sessiondate=%sessiondate:.=%
set sessiondate=%sessiondate:-=%
set sessiondate=%sessiondate:Mon =%
set sessiondate=%sessiondate:Tue =%
set sessiondate=%sessiondate:Wed =%
set sessiondate=%sessiondate:Thu =%
set sessiondate=%sessiondate:Fri =%
set sessiondate=%sessiondate:Sat =%
set sessiondate=%sessiondate:Sun =%
if exist STATS\lastsession.txt goto verifysession
:aftersessioncheck
echo %sessiondate%>STATS\lastsession.txt
set useragent=FGPlayer/1.29 Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0
if exist langs\readyfile.txt type langs\readyfile.txt && goto wffg
echo Done. Please start Fall Guys
echo Report any bugs you encounter to https://github.com/JanGamesHD/FGPlayer/issues
echo Note: If you restart Fall Guys, please restart FGPlayer to reset the log file position.
set skipwaitforfallguyslaunch=0
:wffg
timeout 1 >NUL
rem If you arent running Fall Guys on the host device, you can use this to bypass the "Please start Fall Guys" prompt.
rem Make sure to update the location of the log file at the top of the script!
if %skipwaitforfallguyslaunch%==1 goto fgplayerready
tasklist | find /i "FallGuys"
if not %errorlevel%==0 goto wffg
cls
echo Preparing log file status ...
copy "%logfile%" waitforreadyfile.sys >NUL
cls
echo Fall Guys is now starting.
echo Waiting for the log file to update.
echo If the game is already running, please perform an action ingame to update the log file (open menus).
:wfcilf
timeout 1 >NUL
fc "%logfile%" waitforreadyfile.sys >NUL
if %errorlevel%==0 goto wfcilf
if exist exittimer.sys del exittimer.sys /Q /F >NUL
rem start /min fgtimer.bat
:fgplayerready
cls
echo Preparing Fall Guys log file ...
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
set /p lines=<lines.sys
echo Preparing FGPlayer ...
if not exist stats.qualified.sys echo 0 >stats.qualified.sys
if not exist stats.eliminated.sys echo 0 >stats.eliminated.sys
if not exist stats.wins.sys echo 0 >stats.wins.sys
set /p stats.qualified=<stats.qualified.sys
set /p stats.eliminated=<stats.eliminated.sys
set /p wins=<stats.wins.sys
set skipmmcolor=0
cls
goto cur_mainmenu
:secretmm
echo.
:cur_mainmenu
if %skipmmcolor%==0 color 1
set skipmmcolor=0
echo %text.readymm% LFS: %lines%+ TQ: %stats.qualified% TE: %stats.eliminated%
:aftergotopoint
set disconnectallowed=0	
set linesnomagic=%lines%
set bypassattempt=0
REM echo Your log file currently has %lines%+ lines.
REM echo Total Qualifications: %stats.qualified%
REM echo Total Eliminations: %stats.eliminated%
set usereliminated=0
echo a>quittimer.sys
set blockrewards=0
set completedunimapdetection=0
if exist roundlist.sys del roundlist.sys /Q /F >NUL
:general_waitingarea
if defined genwaitarearest timeout %genwaitarearest% >NUL
if not defined genwaitarearest if %lonelyingamesystem%==1 timeout 1 >NUL
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "​[StateMainMenu] Creating or joining private lobby minimal" TEMP.gen >NUL
if %errorlevel%==0 goto cur_joincustomsmini
find /i "​[StateMainMenu] Creating or joining private lobby" TEMP.gen >NUL
if %errorlevel%==0 goto cur_joincustoms
find /i "[GameStateMachine] Setting initial state to FGClient.StateMainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_loginstatus
find /i "GameMessageServerStartLoadingLevel received" TEMP.gen >NUL
if %errorlevel%==0 if defined wasinmatchmaking goto cur_waitformaptoappear
find /i "​[StateMainMenu] No server address specified, attempting to matchmake" TEMP.gen >NUL
if not %errorlevel%==0 goto general_waitingarea
:cur_connectingmatchmaking
color b
cls
echo ^<00P^> %text.mmconnecting%
echo a>quittimer.sys
:cur_waitformatchmakingconnected
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[FNMMSRemoteServiceBase] Disposed" TEMP.gen >matchdisconnect.txt
if %errorlevel%==0 call :leavematchverify
if %disconnectallowed%==1 goto cur_cancelledmatchmaking
find /i "[FNMMSRemoteServiceBase] FNMMS Websocket connection succeeded." TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitformatchmakingconnected
:cur_connectedtomatchmaking
color 1
cls
echo ^<33P^> %text.mmjoining%
start /min conhost --headless cmd /c timer.bat
if exist TEMP_nomagic.gen del TEMP_nomagic.gen /q /f >nul
set mm.ranonce=0
set wasinmatchmaking=1
set localtext.mmemptystring=%text.mmemptystring%
set sessionassignmentrequested=0
:cur_waitforqueueconnect
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[FNMMSRemoteServiceBase] Disposed" TEMP.gen >matchdisconnect.txt
if %errorlevel%==0 call :leavematchverify
if %disconnectallowed%==1 goto cur_cancelledmatchmaking
find "Queued" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforqueueconnect
color 3
rem cls
echo %ESC%[1;1H^<66P^> %text.mmwaitingplayers%
set matchmakehistory=Connected
set seconds=0
set minutes=0
set lastseconds=1
:cur_queueconnected
find /i  "queuedPlayers" TEMP.gen >tempqueue.temp
For /F "UseBackQ Delims==" %%A In ("%cd%\tempqueue.temp") Do Set queuetemp=%%A
set newqueue=%queuetemp:~21%
if not exist tempnum md tempnum
cd tempnum
md %newqueue%
dir /AD /B >loadgoat.sys
set /p currentmatchplayers=<loadgoat.sys
rd %currentmatchplayers% /Q >NUL
del loadgoat.sys /Q /F >NUL
if not defined currentmatchplayers set currentmatchplayers=null
if not defined lastmatchplayers set lastmatchplayers=yes
set curtime=%time:~0,8%
set curtime=%curtime: =0%
set mm_forremove=0
set /p seconds=<..\seconds.sys
set /a minutes=%seconds%/60
set /a mm_forremove=%minutes%*60
set /a seconds=%seconds%-%mm_forremove%
if %seconds% LSS 10 set seconds=0%seconds%
if %minutes% LSS 10 set minutes=0%minutes%
cd ..
if not %seconds%==%lastseconds% goto cur_mmdisplaytext
if %currentmatchplayers%==%lastmatchplayers% goto cur_playermatchmaking_aftertext
:cur_mmdisplaytext
echo a>startcount.sys
if %bypassattempt%==1 goto cur_playermatchmaking_aftertext
if exist TEMP_nomagic.gen find "SessionAssignment" TEMP_nomagic.gen >nul
set errorhere=%errorlevel%
if %errorhere%==0 if %mm.ranonce%==1 set localtext.mmemptystring=%text.mmsessionassignment% && color e
if not %errorhere%==0 set localtext.mmemptystring=%text.mmemptystring%
if %mm.ranonce%==0 set set localtext.mmemptystring=%text.mmemptystring%
cls
if %currentmatchplayers%==null if %bypassattempt%==0 echo %localtext.mmemptystring%
if not %currentmatchplayers%==null echo %text.mmcurrentplayers%: %currentmatchplayers% (%curtime%, %minutes%:%seconds%)
if not %currentmatchplayers%==null if not %currentmatchplayers%==%lastmatchplayers% set "matchmakehistory=%currentmatchplayers% <-- %matchmakehistory%"
if not %currentmatchplayers%==null echo History: !matchmakehistory!
:cur_playermatchmaking_aftertext
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
set /p lines=<lines.sys
rem set linesnomagic=%lines%
set /a lines=%lines%-%magicnumber%
set lastmatchplayers=%currentmatchplayers%
set lastseconds=%seconds%
:cur_waitforqueueupdate
set mm.ranonce=1
rem "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
if not %errorlevel%==0 goto cur_waitforqueueupdate
more /e +%linesnomagic% "%logfile%" >TEMP_nomagic.gen
if not %errorlevel%==0 goto cur_waitforqueueupdate
find /i "[HazelNetworkTransport] Creating connection with" TEMP.gen >NUL
if %errorlevel%==0 goto cur_connectinggameserver
find /i "[FNMMSRemoteServiceBase] Remote disconnection received. waiting 5s until we close our side" TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitingforgameserver
find /i "[FNMMSRemoteServiceBase] Disposed" TEMP_nomagic.gen >matchdisconnect.txt
if %errorlevel%==0 call :leavematchverify
if %disconnectallowed%==1 goto cur_cancelledmatchmaking
find /i "Queued" TEMP.gen >NUL
if %errorlevel%==0 goto cur_queueconnected
if %lonelyingamesystem%==1 timeout 1 >NUL
goto cur_waitforqueueupdate
:cur_waitingforgameserver
color b
cls
echo %text.mmgameserverstarting%
:cur_waitforserverdetails
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "with FGClient.StateMainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_resettemp
find /i "] Found game on" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforserverdetails
:cur_connectinggameserver
color 7
cls
echo %text.connecting%
echo a>quittimer.sys
:cur_waitforlogin
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find "​[Network] Client connected" TEMP.gen >NUL
if %errorlevel%==0 goto cur_loggingingameserver
find /i "Welcome received" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforlogin
:cur_loggingingameserver
color 1
cls
echo %text.logingameserver%
set currentround=0
:cur_waitforloginsuccess
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
find /i "is allowing us to connect as a" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforloginsuccess
color 6
cls
echo %text.connectedfetchdetails% ...
find /i "[StateConnectToGame] InitiateNetworkConnectRequest with server IP:" TEMP.gen >"%cd%\extractformip.sys"
For /F "UseBackQ Delims==" %%A In ("%cd%\extractformip.sys") Do Set "foripextract=%%A"
set serverip1=%foripextract:*IP: =%
set serverip2=%serverip1:~0,-5%
set serverip2=%serverip2::=%
REM del server_details.sys /Q /F >NUL
REM curl http://ip-api.com/line/%serverip2%?fields=country,regionName,city --silent >server_details.sys
ping %serverip2% -n 1 -w 2000 >"%cd%\pinganswer.sys"
for /f "tokens=1*delims=:" %%G in ('findstr /n "^" "%cd%\pinganswer.sys"') do if %%G equ 3 set ping1=%%H
md pingtest
set currentcd=%cd%
cd pingtest
md %ping1% 2>NUL
dir *ms /AD /B >"%currentcd%\ping2server.sys
cd ..
rd pingtest /Q /S
set loadping=0ms
set /p loadping=<ping2server.sys
rem if not %loadping%==0ms echo Ping: %loadping%
REM echo You are connected to %serverip2%.
REM echo Your ping is %loadping%.
REM echo Selected Show: Loading ...
REM echo Server location:
REM type server_details.sys
:cur_waitforshowtofetch
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[HandleSuccessfulLogin] Selected show is " TEMP.gen >"%cd%\4showselector.sys"
if not %errorlevel%==0 goto cur_waitforshowtofetch
:9worksuc
set isexplore=0
set issquad=0
For /F "UseBackQ Delims==" %%A In ("%cd%\4showselector.sys") Do Set "showselected=%%A"
find ": True" 4showselector.sys >NUL
if %errorlevel%==0 set isexplore=1
find "squad" 4showselector.sys >NUL
if %errorlevel%==0 set issquad=1
if %issquad%==0 find "duo" 4showselector.sys >NUL
if %issquad%==0 if %errorlevel%==0 set issquad=1
set selectedshow1=%showselected:*is =%
set selectedshow1=%selectedshow1:IsUltimatePartyEpisode=%
set selectedshow1=%selectedshow1:IsUltimatePartyEpisode=%
set selectedshow1=%selectedshow1:: False=%
set selectedshow1=%selectedshow1:: True=%
rem Default max players for shows not saved.
set maxloadedplayers=32
set selectedshow1=%selectedshow1: =%
echo %selectedshow1%>selectedshow.sys
set showname=
if exist FGPLAYER\SHOWSELECTOR\%selectedshow1%.sys set /p maxloadedplayers=<FGPLAYER\SHOWSELECTOR\%selectedshow1%.sys
if exist FGPLAYER\SHOWSELECTOR\%selectedshow1%.name set /p showname=<FGPLAYER\SHOWSELECTOR\%selectedshow1%.name
if not defined showname set showname=unknown
cls
echo %text.connectedfetchdetails%. %text.connectedshow%: %selectedshow1% %text.connectedping%: %loadping%
set maplist=
set bypasscancelmatch=
REM echo You are connected to %serverip2%. Ping: %loadping%.
REM if "%showname%"=="unknown" echo Selected Show: %selectedshow1%
REM if not "%showname%"=="unknown" echo Selected Show: %showname% (%selectedshow1%)
REM echo Max players set to %maxloadedplayers%. Server location:
REM type server_details.sys
set /p lines=<lines.sys
find /i "[CreateLocalPlayerInstances] Added new player as Participant, player ID = " TEMP.gen >playeridout.sys
tail.exe -1 playeridout.sys>playeridout2.sys
set /p tempplayerid=<playeridout2.sys
set myplayerid=%tempplayerid:~88%
cls
echo %text.connectedfetchdetails%. %text.connectedshow%: %selectedshow1% %text.connectedping%: %loadping% %text.connectedpid%: %myplayerid% %text.issquadgame%: %issquad%
rem echo Player ID: %myplayerid% SQ: %issquad%
:cur_waitformaploadstart
if %lonelyingamesystem%==1 timeout 1 >NUL
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "​[Hazel] [HazelNetworkTransport] Disconnect request received for connection 0" TEMP.gen >NUL
if %errorlevel%==0 goto serverdisconnectedyou
find /i "with FGClient.StateMainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto serverdisconnectedyou
find /i "​[RoundLoader] Loading finished" TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitformaptoappear
find /i "GameMessageServerStartLoadingLevel received" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitformaploadstart
:cur_waitformaptoappear
cls
echo %text.loading_waitmap%
set completedunimapdetection=0
set completedcreativelevel=0
set wasinmatchmaking=
set iscreative=0
set dotload=.
set gmncode=unknown
set dotcount=0
set addinfo=
:cur_waitforanimationtofinish
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
echo %ESC%[1;1H%text.loading_waitmap% %dotload%
if %dotcount% LSS 100 set dotload=%dotload%.
if %dotcount% LSS 100 set /a dotcount=%dotcount%+1
more /e +%lines% "%logfile%" >TEMP.gen
find /i "Requesting spawn of local player" TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitformaploadtocomplete
find /i "[StateGameLoading] ShowLoadingGameScreenAndLoadLevel" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforanimationtofinish
color c
cls
echo %text.loadingmap%
if exist private\fmedia.bat taskkill /F /IM fmedia.exe >NUL
set dotload=.
set dotcount=0
set mapmsg=Empty
:cur_waitformaploadtocomplete
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
if %completedunimapdetection%==1 goto cur_onlywaitformapload
find /i "​[RoundLoader] Game level to load:" TEMP.gen >loadearlymapname.txt
if %errorlevel%==0 set dotcount=1 && goto cur_loadearlymapname
if %completedcreativelevel%==1 goto cur_onlywaitformapload
find /i "[RoundLoader] Load UGC via share code" TEMP.gen >creativesharecode.txt
if %errorlevel%==0 set dotcount=1 && goto cur_creativeleveldetected
:cur_onlywaitformapload
find /i "[RoundLoader] Loading finished with state Cancelled" TEMP.gen >NUL
if %errorlevel%==0 goto failedtoloadlevel
if %dotcount% GEQ 1 echo %ESC%[1;1H%mapmsg% %dotload%
if %dotcount% LSS 300 set dotload=%dotload%.
if %dotcount% LEQ 300 set /a dotcount=%dotcount%+1
find /i "[ClientGameManager] GameLevelLoaded" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitformaploadtocomplete
cls
echo %text.loadingmap_done%
color e
if exist private\fmedia.bat taskkill /F /IM fmedia.exe >NUL
if not exist STATS\SESSION\ROUNDS\%gmncode%\ md STATS\SESSION\ROUNDS\%gmncode%
if not exist STATS\ALLTIME\ROUNDS\%gmncode%\ md STATS\ALLTIME\ROUNDS\%gmncode%
type nul>quittimer.sys
find /i "[StateGameLoading] Finished loading game level, assumed to be" TEMP.gen >mapresults1.sys
For /F "UseBackQ Delims==" %%A In ("%cd%\mapresults1.sys") Do Set lastlinemap=%%A
set lastlinemap2=%lastlinemap:~76%
set lastlinemap3=%lastlinemap2:.=%
set lastlinemap4=%lastlinemap3: Duration:=%
set lastlinemap5=%lastlinemap4:,=.%
rem if "%lastlinemap5%"==".=" goto trytofixmapdetection
md MapLookupV2
cd MapLookupV2
md %lastlinemap5%
dir /B>..\loaderoutput.txt
set /p loadtime=<..\loaderoutput.txt
rd %loadtime% /Q
dir /B>..\loaderoutputmap.txt
set /p rawmap=<..\loaderoutputmap.txt
cd ..
rd MapLookupV2 /Q /S
if %completedunimapdetection%==1 goto skipunisearch
find /i "​[RoundLoader] LoadGameLevelSceneASync COMPLETE for scene " TEMP.gen >mapresults2.sys
For /F "UseBackQ Delims==" %%A In ("%cd%\mapresults2.sys") Do Set lastlinemapuni=%%A
set mapworker=%lastlinemapuni:~72%
set mapworker25=%mapworker:e =%
set mapworker2=%mapworker25: on frame=%
md MapLookupV2
cd MapLookupV2
md %mapworker2%
dir fram* /B>..\loaderoutput2.txt
set /p framedata=<..\loaderoutput2.txt
rd %framedata% /Q
dir /B>..\loaderoutputmap2.txt
set /p unimap=<..\loaderoutputmap2.txt
cd ..
rd MapLookupV2 /Q /S
set theunimap=%unimap%
:skipunisearch
set maploadtime=%loadtime%
set themap=%rawmap%
set creativemap=0
if %theunimap%==FallGuy_FraggleBackground_Retro set creativemap=1
if %theunimap%==FallGuy_FraggleBackground_Vanilla set creativemap=2
if %creativemap%==1 if exist MAPS\currentcreativevanilla.sys del MAPS\currentcreativevanilla.sys /Q /F
if %creativemap%==2 if exist MAPS\currentcreative.sys del MAPS\currentcreative.sys /Q /F
if %creativemap%==1 echo %themap%>MAPS\currentcreative.sys
if %creativemap%==2 echo %themap%>MAPS\currentcreativevanilla.sys
rem if %creativemap%==1 if exist MAPS\%themap%.map set /p mapname=<MAPS\%themap%.map
rem if %creativemap%==2 if exist MAPS\%themap%.mapvanilla set /p mapname=<MAPS\%themap%.mapvanilla
rem if %creativemap%==1 if not exist MAPS\%themap%.map goto loadanyway
rem if %creativemap%==2 if not exist MAPS\%themap%.mapvanilla goto loadanyway
if %creativemap%==1 goto cur_afterclassicmap
if %creativemap%==2 goto cur_afterclassicmap
rem we are skipping classic map, since its a creative map, and we dont need to load the classic map name.
set diddosharecode=0
set didmaptest=1
rem if %creativemap%==0 echo Not a creative level.
:loadanyway
echo %unimap%>MAPS\currentmap.sys
if %completedunimapdetection%==1 goto cur_afterclassicmap
rem echo Loading map name...
set mapname=
set curloadedplayers=0
if not exist MAPS\%unimap%.map goto endingnewmap
set /p mapname=<MAPS\%unimap%.map
:cur_afterclassicmap
color e
if %performclip%==1 echo %mapname% (%theunimap%) - %themap% | clip
if defined addinfo set addinfo=%maploadtime%, %addinfo%
if not defined addinfo set addinfo=%maploadtime%
rem if not %curloadedplayers%==%lastloadedplayers% goto endingnewmap
if not defined curloadedplayers set curloadedplayers=0
if not defined lastloadedplayers set lastloadedplayers=-1
:endingnewmap
set completedunimapdetection=0
if not defined mapname set mapname=%theunimap:FallGuy_=%
set remain=0
set /a remain=%maxloadedplayers%-%curloadedplayers%
if %usereliminated%==1 goto skip_usereliminated
set /a curloadedplayers2=%curloadedplayers%-1
set /a remain2=%remain%+1
:skip_usereliminated
if %usereliminated%==1 set /a remain2=%remain%+2
if %usereliminated%==1 set /a curloadedplayers2=%curloadedplayers%-2
if %remain2% LEQ 0 goto cur_maploadonlyplayers
rem cls
echo %ESC%[1;1H%text.maploaded_players%: %curloadedplayers2%/%maxloadedplayers% - %text.maploaded_playersleft%: %remain2% - %text.maploaded_map%: !mapname! (%addinfo%)  
REM echo Map: %mapname% (%theunimap:FallGuy_=%) - %themap%
REM echo Players: %curloadedplayers2%/%maxloadedplayers%
REM echo Remain: %remain2%
:cur_waitforplayerupdate
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
set lastloadedplayers=%curloadedplayers%
find /i "[ClientGameManager] Handling bootstrap for remote player" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set curloadedplayers=%%b
if not %curloadedplayers%==%lastloadedplayers% goto endingnewmap
find /i "[CameraDirector].UseIntroCameras, current camera target type is Close" TEMP.gen >NUL
if %errorlevel%==0 goto waitlastfewplayers
find /i "[StateGameLoading].OnIntroCamerasComplete, spawning players post intro camera" TEMP.gen >NUL
if %errorlevel%==0 goto showintro
find /i "[StateMainMenu] Loading scene MainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_clsmainmenu
find /i "[ClientGameManager] Setting this client as readiness state 'ObjectsSpawned'." TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforplayerupdate
:waitlastfewplayers
color 6
cls
echo %text.mapload_waitplayers%
:cur_waitforserverintro
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[GameSession] Changing state from Precountdown to Countdown" TEMP.gen >NUL
if %errorlevel%==0 goto showintro
find /i "[CameraDirector].UseIntroCameras, current camera target type is Close" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforserverintro
goto showintro
cls
echo Waiting for server...
:cur_waitforservertostartintro
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[StateGameLoading].OnIntroCamerasComplete, spawning players post intro camera" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforservertostartintro
:showintro
color b
set /a curloadedplayers=%curloadedplayers%-1
cls
echo %text.maploaded_map%: !mapname! - %text.maploaded_players%: %curloadedplayers%
if %iscreative%==1 if not exist STATS\ALLTIME\UGC2MAP\%sharecode%.txt echo %themap%>STATS\ALLTIME\UGC2MAP\%sharecode%.txt
REM echo Showing the map ...
REM echo Map: %mapname%
REM echo Players: %curloadedplayers%
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" "%cd%"\TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
set pcplayers=0
set pcegplayers=0
set ps4players=0
set ps5players=0
set xboxplayers=0
set switchplayers=0
set xboxoneplayers=0
set iosplayers=0
set androidplayers=0
set botplayers=0
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
if defined skipplayernums goto cur_afterplayerlistings
rem PC STEAM
set playerlistings=
find /i "[CameraDirector] Adding Spectator target ... (pc_steam)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set pcplayers=%%b
if not %pcplayers% LEQ 0 set /a pcplayers=%pcplayers%-2
if %pcplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.steam%: %pcplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo PC PLAYERS EPIC
find /i "[CameraDirector] Adding Spectator target ... (pc_egs)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set pcegplayers=%%b
if not %pcegplayers% LEQ 0 set /a pcegplayers=%pcegplayers%-2
if %pcegplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.epic%: %pcegplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo PS4 PLAYERS
find /i "[CameraDirector] Adding Spectator target ... (ps4)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set ps4players=%%b
if not %ps4players% LEQ 0 set /a ps4players=%ps4players%-2
if %ps4players% GTR 0 set playerlistings=%playerlistings% %text.platform.ps4%: %ps4players% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo PS5 PLAYERS
find /i "[CameraDirector] Adding Spectator target ... (ps5)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set ps5players=%%b
if not %ps5players% LEQ 0 set /a ps5players=%ps5players%-2
if %ps5players% GTR 0 set playerlistings=%playerlistings% %text.platform.ps5%: %ps5players% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo XBOX PLAYERS
find /i "[CameraDirector] Adding Spectator target ... (xsx)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set xboxplayers=%%b
if not %xboxplayers% LEQ 0 set /a xboxplayers=%xboxplayers%-2
if %xboxplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.xsx%: %xboxplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo XBOX ONE PLAYERS
find /i "[CameraDirector] Adding Spectator target ... (xb1)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set xboxoneplayers=%%b
if not %xboxoneplayers% LEQ 0 set /a xboxoneplayers=%xboxoneplayers%-2
if %xboxoneplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.xb1%: %xboxoneplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo SWITCH PLAYERS
find /i "[CameraDirector] Adding Spectator target ... (switch)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set switchplayers=%%b
if not %switchplayers% LEQ 0 set /a switchplayers=%switchplayers%-2
if %switchplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.switch%: %switchplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo MOBILE IOS
find /i "[CameraDirector] Adding Spectator target ... (ios_ega)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set iosplayers=%%b
if not %iosplayers% LEQ 0 set /a iosplayers=%iosplayers%-2
if %iosplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.iosega%: %iosplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo MOBILE ANDROID
find /i "[CameraDirector] Adding Spectator target ... (android_ega)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set androidplayers=%%b
if not %androidplayers% LEQ 0 set /a androidplayers=%androidplayers%-2
if %androidplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.androidega%: %androidplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
rem echo BOTS
find /i "[CameraDirector] Adding Spectator target ... (bots)" TEMP.gen >playerlistfile.log
for /f "usebackq" %%b in (`type playerlistfile.log ^| find "" /v /c`) do set botplayers=%%b
if not %botplayers% LEQ 0 set /a botplayers=%botplayers%-2
if %botplayers% GTR 0 set playerlistings=%playerlistings% %text.platform.bots%: %botplayers% && echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
if not defined playerlistings set playerlistings=Loading...
rem echo %playerlistings%
set totalplayers=0
set /a totalplayers=%pcplayers%+%pcegplayers%+%ps4players%+%ps5players%+%xboxplayers%+%xboxoneplayers%+%switchplayers%+%iosplayers%+%androidplayers%+%botplayers%
if not %totalplayers%==%curloadedplayers% cls
if not %totalplayers%==%curloadedplayers% echo Map: !mapname! Players: %curloadedplayers%
REM if not %totalplayers%==%curloadedplayers% echo Showing the map ...
REM if not %totalplayers%==%curloadedplayers% echo Map: %mapname%
REM if not %totalplayers%==%curloadedplayers% echo Players: %totalplayers%
:cur_afterplayerlistings
if defined skipplayernums set totalplayers=%curloadedplayers%
if not %totalplayers%==%curloadedplayers% set curloadedplayers=%totalplayers%
if not defined skipplayernums (
rem cls
echo %ESC%[1;1H%text.platform.map%: !mapname! - %text.platform.players%: %curloadedplayers% - %playerlistings:~1%
)
if not %issquad%==0 goto cur_waitforcountdown
if not %currentround%==0 goto cur_waitforcountdown
find "Squad ID: 1" TEMP.gen >NUL
set error=%errorlevel%
if %error%==0 echo Squads detected and enabled.
if %error%==0 set issquad=1
:cur_waitforcountdown
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" "%cd%"\TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[StateMainMenu] Loading scene MainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_checkaddelimmainmenu
find /i "[ClientGameManager] Setting this client as readiness state 'ReadyToPlay'." TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforcountdown
color 5
cls
echo %text.pregame.wait%
set /a currentround=%currentround%+1
REM echo R%currentround%: %mapname%
REM echo Players: %curloadedplayers%
rem findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys # removed on 28.10.2025 R.I.P Nala :(
:cur_waitforcountdown2
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" "%cd%"\TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[StateMainMenu] Loading scene MainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_checkaddelimmainmenu
find /i "[GameSession] Changing state from Precountdown to Countdown" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforcountdown2
color c
set /p lines=<lines.sys 
cls
REM echo 3... 2... 1...
rem set /a currentround=%currentround%+1
if defined skipplayernums echo %text.pregame.countdown% %text.pregame.roundprefix%%currentround%: !mapname! - %text.pregame.players%: %curloadedplayers%
if not defined skipplayernums echo %text.pregame.countdown% %text.pregame.roundprefix%%currentround%: !mapname! - %text.pregame.players%: %curloadedplayers% - %playerlistings:~1%
REM echo Players: %curloadedplayers%
rem if not defined skipplayernums echo %playerlistings:~1%
start /min conhost --headless cmd /c timer.bat
if not defined showcounter set showcounter=0

:cur_waitforgamestart
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" "%cd%"\TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[GameSession] Changing state from Countdown to Playing" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforgamestart
color e
cls
echo Loading ...
type nul>startcount.sys
set seconds=0
set lastseconds=0
set qualified=0
set qualifiedseconds=0
set playersqualified=0
set lastplayersqualified=0
set playerseliminated=0
set lastplayerseliminated=0
set /p lines=<lines.sys
rem Initial Starting zone
if %usenewingamesystem%==1 goto newingame
if %lonelyingamesystem%==1 goto lonelyingame
call :cur_gamerunning
goto cur_ingame
:cur_gamerunning
if %qualified%==0 set text=%text.ingame.time%: %seconds%
if %qualified%==1 set text=%text.ingame.time%: %seconds% %text.ingame.qualifiedownprefix%: %qualifiedseconds%
set text=%text% %text.ingame.roundprefix%%currentround%: !mapname!
if %playersqualified% GTR 0 set text=%text% - %text.ingame.totalqualified%: %playersqualified%
if %playerseliminated% GTR 0 set text=%text% - %text.ingame.totaleliminated%: %playerseliminated%
if %usereliminated%==1 set text=%text% %text.ingame.owneliminated%
rem cls
echo %ESC%[1;1H%text%
goto :EOF
:cur_ingame
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" "%cd%"\TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
if %qualified%==1 goto cur_afterqualifiedcheck
find /i "ClientGameManager::HandleServerPlayerProgress PlayerId=%myplayerid% is succeeded=True" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_afterqualifiedcheck
set qualified=1
set qualifiedseconds=%seconds%
if %blockrewards%==1 call :cur_gamerunning
set /a stats.qualified=%stats.qualified%+1
echo %stats.qualified% >stats.qualified.sys
start /min cmd /c stats_addqualify.bat
call :cur_gamerunning
:cur_afterqualifiedcheck
find /i "[ClientGameSession] NumPlayersAchievingObjective=" TEMP.gen>qualifynumbers.sys
if not %errorlevel%==0 goto cur_aftercheckingqualificationnumbers
tail -1 "%cd%\qualifynumbers.sys">"%cd%\qualifynumbers2.sys"
set /p lastqualify=<"%cd%\qualifynumbers2.sys"
set almostqualifynumber=%lastqualify:*ve=ve%
set playersqualified=%almostqualifynumber:~3%
if %lastplayersqualified%==%playersqualified% goto cur_aftercheckingqualificationnumbers
set lastplayersqualified=%playersqualified%
call :cur_gamerunning
:cur_aftercheckingqualificationnumbers
rem more /e +%lines% "%cd%\TEMP1.log" >"%cd%"\specialtemp.sys
find /i "is succeeded=False" TEMP.gen >elimplayers.sys
if not %errorlevel%==0 goto cur_aftercheckingeliminationnumbers
for /f "usebackq" %%b in (`type elimplayers.sys ^| find "" /v /c`) do set elimnumber=%%b
set /a elimnumber=%elimnumber%-2
if %elimnumber% GTR 0 set playerseliminated=%elimnumber%
if %usereliminated%==1 goto afteringameelimcheck
find /i "Qualified: False" TEMP.gen>NUL
if not %errorlevel%==0 goto afteringameelimcheck
set usereliminated=1
if %blockrewards%==1 goto afteringameelimcheck
set /a stats.eliminated=%stats.eliminated%+1
echo %stats.eliminated% >stats.eliminated.sys
start /min cmd /c stats_addelimination.bat
:afteringameelimcheck
if %playerseliminated%==%lastplayerseliminated% goto cur_aftercheckingeliminationnumbers
set lastplayerseliminated=%playerseliminated%
call :cur_gamerunning
:cur_aftercheckingeliminationnumbers
set newseconds=
set /p newseconds=<seconds.sys
if not defined newseconds set newseconds=%seconds%
if %newseconds%==%seconds% goto cur_aftercheckingseconds
set seconds=%newseconds%
set lastseconds=%seconds%
call :cur_gamerunning
:cur_aftercheckingseconds
:aftercheckingseconds
find /i "[StateMainMenu] Loading scene MainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_checkaddelimmainmenu
if not %isexplore%==1 goto afterexplorecheck
find /i "[GameplaySpectatorUltimatePartyFlowViewModel] Matchmaking begins!" TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
find /i "[MatchmakeWhileInGameHandler] Begin matchmaking..." TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
:afterexplorecheck
find /i "[GameSession] Changing state from Playing to GameOver" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_ingame
if not %playersqualified%==0 goto skipsurvivalmaptest
find /C "is succeeded=True" TEMP.gen | find "-" >abuild.txt
set /p inl=<abuild.txt
set playersqualified=%inl:~-2%
set playersqualified=%playersqualified: =%
:skipsurvivalmaptest
color c
rem cls
echo %ESC%[1;1HRound %currentround% Over! Took: %seconds: =%s - Map: !mapname!
find /i "is succeeded=True" TEMP.gen >successlist.txt
more /e +2 successlist.txt >successlist2.txt
findstr /R /N "^" "successlist2.txt" | find /C ":" >qualplayers.txt
set /p playersqualified=<qualplayers.txt
cls
echo %ESC%[1;1H%text.roundover.round% %currentround% %text.roundover.over% %text.roundover.timetook%: %seconds: =%s - %text.roundover.map%: !mapname! - %text.roundover.qualified%: %playersqualified%
set usernoteliminated=0
echo R%currentround%: !mapname! (%maxloadedplayers% --^> %playersqualified%) >>roundlist.sys
set "elimaction=(%maxloadedplayers% --> %playersqualified%)"
set "elimaction2=(--> %playersqualified%)"
if %currentround%==1 (
	set "roundhistory=R%currentround%: !mapname! !elimaction!"
	)

if %currentround% GTR 1 (
	set "roundhistory=!roundhistory! R%currentround%: !mapname! !elimaction2!"
	)

rem set roundhistory=%roundhistory%
REM if defined maplist set maplist=%maplist% R%currentround%: %mapname% (%maxloadedplayers% --^> %playersqualified%)
REM if not defined maplist set maplist=R%currentround%: %mapname% (%maxloadedplayers% --^> %playersqualified%)
set maxloadedplayers=%playersqualified%
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
type nul>quittimer.sys
:cur_waitfortotalrounddisplay
if %lonelyingamesystem%==1 timeout 1 >NUL
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" "%cd%"\TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
if %usereliminated%==1 goto cur_afterrounddisplaycheck
if %usernoteliminated%==1 goto cur_afterrounddisplaycheck
find /i "Qualified: False" TEMP.gen>NUL
if %errorlevel%==0 goto cur_roundoverelimuser
find "Qualified: True" TEMP.gen>NUL
if %errorlevel%==0 (
rem cls
color 6
echo %ESC%[1;1H%text.roundover.round% %currentround% %text.roundover.over% %text.roundover.timetook%: %seconds: =%s - %text.roundover.map%: !mapname! - %text.roundover.qualified%: %playersqualified% - %text.roundover.youwon%
set usernoteliminated=1
if exist private\fmedia\fmedia.exe start /min conhost --headless cmd /c private\fmedia\fmedia.exe private\fmedia\won.mp3
if not exist STATS\SESSION\ROUNDS\%gmncode%\ md STATS\SESSION\ROUNDS\%gmncode%
if not exist STATS\SESSION\ROUNDS\%gmncode%\wins.sys echo 0 >STATS\SESSION\ROUNDS\%gmncode%\wins.sys
set /p gmnwins=<STATS\SESSION\ROUNDS\%gmncode%\wins.sys
set gmnwins=%gmnwins: =%
set /a gmnwins=%gmnwins%+1
echo %gmnwins% >STATS\SESSION\ROUNDS\%gmncode%\wins.sys
if not exist STATS\ALLTIME\ROUNDS\%gmncode%\ md STATS\ALLTIME\ROUNDS\%gmncode%
if not exist STATS\ALLTIME\ROUNDS\%gmncode%\wins.sys echo 0 >STATS\ALLTIME\ROUNDS\%gmncode%\wins.sys
set /p gmnwins=<STATS\ALLTIME\ROUNDS\%gmncode%\wins.sys
set gmnwins=%gmnwins: =%
set /a gmnwins=%gmnwins%+1
echo %gmnwins% >STATS\ALLTIME\ROUNDS\%gmncode%\wins.sys
)
goto cur_afterrounddisplaycheck
:cur_roundoverelimuser
set usereliminated=1
if %blockrewards%==1 goto cur_afterroundoverelimwrite
set /a stats.eliminated=%stats.eliminated%+1
echo %stats.eliminated% >stats.eliminated.sys
start /min cmd /c stats_addelimination.bat
:cur_afterroundoverelimwrite
cls
echo %ESC%[1;1H%text.roundover.round% %currentround% %text.roundover.over% %text.roundover.timetook%: %seconds: =%s - %text.roundover.map%: !mapname! - %text.roundover.qualified%: %playersqualified% - %text.roundover.youeliminated%
:cur_afterrounddisplaycheck
find /i "[StateMainMenu] Loading scene MainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_checkaddelimmainmenu
find /i "[GameStateMachine] Replacing FGClient.StateGameInProgress with FGClient.StateVictoryScreen" TEMP.gen>NUL
if %errorlevel%==0 goto showend
if not %isexplore%==1 goto afterexplorecheck2
find /i "[GameplaySpectatorUltimatePartyFlowViewModel] Matchmaking begins!" TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
find /i "[MatchmakeWhileInGameHandler] Begin matchmaking..." TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
:afterexplorecheck2
set /p lines=<lines.sys
find /i "[StateQualificationScreen] Reloading for next round" TEMP.gen>NUL
if not %errorlevel%==0 goto cur_waitfortotalrounddisplay
color 5
cls
REM echo Mhh. Which round will come next?
rem type roundlist.sys
echo !roundhistory!
REM echo %maplist%
goto cur_waitformaploadstart

:showend
cls
echo %text.victory.victoryscreen%
set skipmmclolor=1
if %usereliminated%==1 goto lostshow2
if %blockrewards%==1 goto showend_blockrewards
goto cur_waitforrewards_decision
if %qualified%==1 goto cur_afterwoncheck
if %usereliminated%==1 goto lostshow2
goto cur_waitforrewards_decision
find /i "ClientGameManager::HandleServerPlayerProgress PlayerId=%myplayerid% is succeeded=True" TEMP.gen >NUL
if not %errorlevel%==0 goto lostshow
:cur_afterwoncheck
cls
color 6
set /a wins=%wins%+1
echo %wins% >stats.wins.sys
echo %text.victory.have% %wins% %text.victory.have2%.
echo !roundhistory!
echo %text.victory.qualified%: %playersqualified%
goto secretmm

:lostshow
if %issquad%==1 goto cur_waitforrewards_decision
:afterdecision
color 5
cls
set /a stats.eliminated=%stats.eliminated%+1
echo %stats.eliminated% >stats.eliminated.sys
:lostshow2
cls
echo %text.victory.lost%.
echo !roundhistory!
echo %text.victory.qualified%: %playersqualified%
goto secretmm

:cur_clsmainmenu
cls
goto cur_mainmenu

:cur_waitforexplorematchmaking
cls
echo a>quittimer.sys
echo %text.explore.waitmm%
set bypasscancelmatch=1
goto cur_connectingmatchmaking

:showresultsmsg
echo !roundhistory!
echo %%text.victory.qualified%%: %playersqualified%
goto :EOF
:cur_maploadonlyplayers
rem cls
echo %ESC%[1;1H%text.maploaded_players%: %curloadedplayers2% - %text.maploaded_map%: !mapname! (%addinfo%).                                                                     
REM echo Map loaded in %maploadtime%. Waiting for players.
REM echo Map: %mapname% (%theunimap:FallGuy_=%) - %themap%
REM echo Players: %curloadedplayers2%
goto cur_waitforplayerupdate

:cur_waitforrewards_decision
cls
echo %text.victory.victoryscreen%
echo Waiting for rewards ...
set /a lines=%lines%-200
:loop_waitforrewards_decision
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[StateMainMenu] Loading scene MainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_clsmainmenu
REM find /i "[PlayerStats] [UpdateCache] Player stats updated" TEMP.gen >NUL
REM if %errorlevel%==0 goto cur_processingrewards
REM find /i "[RewardService] Processing claimed rewards" TEMP.gen >NUL
REM if not %errorlevel%==0 goto loop_waitforrewards_decision
find /i "BadgeId: " TEMP.gen >NUL
if not %errorlevel%==0 goto loop_waitforrewards_decision
:cur_processingrewards
cls
echo Victory Screen
echo Processing rewards ...
find "Qualified: False" TEMP.gen >NUL
if %errorlevel%==0 goto afterdecision
goto cur_afterwoncheck

:cur_joincustomsmini
cls
set blockrewards=1
set wasinmatchmaking=1
echo NOTE: This is a discovery level. Rewards are disabled.
echo.
echo Connecting to matchmaking ...
goto cur_waitformatchmakingconnected

:cur_joincustoms
cls
set blockrewards=1
set wasinmatchmaking=1
echo Connected to Custom Show.
echo NOTE: This is a custom show. Rewards are disabled.
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
set /p lines=<lines.sys
echo.
echo Waiting for the host to start ...
:cur_waitforcustomstart
rem copy "%userprofile%\AppData\LocalLow\Mediatonic\FallGuys_client\Player.log" TEMP1.log >NUL
more /e +%lines% "%logfile%" >TEMP.gen
find /i "[PartyStateManager] Attempting to create core party after returning to main menu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_resettemp
find /i "[GameStateMachine] Replacing FGClient.StatePrivateLobby with FGClient.StateConnectToGame" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitforcustomstart
goto cur_connectinggameserver

:showend_blockrewards
echo Rewards are disabled for Custom Shows.
echo No changes have been made to your stats.
goto cur_mainmenu

:leavematchverify
if not exist pastmatchdisconnect.txt goto disconnectcorrect
fc pastmatchdisconnect.txt matchdisconnect.txt >NUL
if %errorlevel%==0 goto dontdisconnect
if defined bypasscancelmatch goto dontdisconnect
:disconnectcorrect
copy matchdisconnect.txt pastmatchdisconnect.txt >nul
set disconnectallowed=1
goto :EOF

:dontdisconnect
set disconnectallowed=0
goto :EOF
:cur_cancelledmatchmaking
echo FGPlayer Log File Manager
echo.
echo Please wait, resetting log file ...
echo a>quittimer.sys
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
set /p lines=<lines.sys
set disconnectallowed=0
cls
echo Matchmaking cancelled. Disconnected from matchmaking.
cls && goto cur_mainmenu

:cur_resettemp
cls
echo FGPlayer Log File Manager
echo.
echo Please wait, resetting log file ...
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
set /p lines=<lines.sys
cls
goto cur_mainmenu

:cur_loadearlymapname
rem loadearlymapname.txt
tail -1 loadearlymapname.txt >earlymapname.txt
set /p earlymapname=<earlymapname.txt
set earlymapname=%earlymapname:~49%
if exist earlymapname\ rd earlymapname /Q /S
md earlymapname
cd earlymapname
md %earlymapname% 2>NUL
dir FallGuy_* /OD /B >correctmap.txt
more /e +1 correctmap.txt >outmap.txt
type nul>empty.sys
fc outmap.txt empty.sys >nul
if %errorlevel%==0 goto mid_skipsafemapcheck
rem 2 different maps, deleting prev to load correctly
rd %theunimap% /q
dir FallGuy_* /OD /B >correctmap.txt
:mid_skipsafemapcheck
set /p theunimap=<correctmap.txt
cd ..
set completedunimapdetection=1
set unimap=%theunimap%
if not exist MAPS\%unimap%.map set mapname=%unimap:FallGuy_=%
if exist MAPS\%unimap%.map set /p mapname=<MAPS\%unimap%.map
rem cls
echo %ESC%[1;1H%text.loadingmap_known% !mapname! (%theunimap%) ...
set gmncode=%theunimap%
set mapmsg=%text.loadingmap_known% !mapname! (%theunimap%) ...
if %performclip%==1 echo %mapname% (%theunimap%) | clip
if not exist STATS\ALLTIME\ROUNDS\%theunimap%\plays.txt goto cur_onlywaitformapload
dir /tw STATS\ALLTIME\ROUNDS\%theunimap%\plays.txt | find "plays.txt" >getlvllastplay.txt
set /p addinfo=<getlvllastplay.txt
set addinfo=%addinfo:~0,17%
set /p mapstatsqual=<STATS\ALLTIME\ROUNDS\%theunimap%\qualifications.txt
set /p mapstatselim=<STATS\ALLTIME\ROUNDS\%theunimap%\eliminations.txt

rem if %mapstatsqual%==0 set fractional=0 && goto aftermath_creativemap
rem if %mapstatselim%==0 set fractional=100 && goto aftermath_creativemap

:: 1. Calculate total matches (Denominator)
set /a totalmatches_leg=%mapstatsqual% + %mapstatselim%

:: 2. If total is 0, skip to prevent a crash (Division by Zero)
if %totalmatches_leg%==0 (
    rem echo Qualification Rate: 0.00%%
    goto cur_onlywaitformapload
)

:: 3. Multiply quals by 10000 and divide by total
set /a scaled=(%mapstatsqual% * 10000) / %totalmatches_leg%

:: 4. Extract whole and fractional parts
set /a whole=%scaled% / 100
set /a frac_raw=%scaled% %% 100

:: 5. Pad leading zero for the fractional part if needed
if %frac_raw% LSS 10 (
    set fractional=0%frac_raw%
) else (
    set fractional=%frac_raw%
)

rem echo Qualification Rate: %whole%.%fractional%%%
set whole=%whole: =%
set fractional=%fractional: =%
set addinfo=%addinfo% QR %whole%.%fractional%P
goto cur_onlywaitformapload

:serverdisconnectedyou
cls
set skipmmcolor=1
color c
echo Disconnected from game server. Checking status ...
find "[ClientGlobalGameState] sending graceful disconnect message" TEMP.gen >NUL
if %errorlevel%==0 goto disconnect_notserverfault
cls
echo You have been disconnected by the server!
echo For some reason, the server closed your connection. Thats all we know.
:cur_recalclinesafterdisconnect
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
set /p lines=<lines.sys
goto cur_mainmenu

:disconnect_notserverfault
cls
echo Player requested disconnection. Returning to main menu.
goto cur_recalclinesafterdisconnect

rem [GameStateMachine] Replacing FGClient.StateMatchmaking with FGClient.StateDisconnectingFromServer
:createstats
echo Creating stats ...
echo This shoudnt take long.
md STATS
md STATS\ALLTIME
md STATS\SESSION
md STATS\PASTSESSIONS
rem Important: No crossover of stats are ever allowed.
rem SESSION stats start when FGPlayer starts. FGPlayer records the current date and uses it to identify the current session.
rem This means that if you restart Fall Guys and FGPlayer, if its still the same date as before, the same session will be used.
rem Old sessions will be moved into STATS\PASTSESSIONS, and the FGStatsView.bat can be used to view stats based on those past sessions.
goto afterstatscreation

:failedtoloadlevel
cls
echo Failed to load level.
color c
findstr /R /N "^" "%logfile%" | find /C ":" >lines.sys
set /p lines=<lines.sys
set skipmmcolor=1
goto cur_mainmenu

:verifysession
set /p lastsession=<STATS\lastsession.txt
if %sessiondate%==%lastsession% goto aftersessioncheck
ren STATS\SESSION %lastsession%
move STATS\%lastsession% STATS\PASTSESSIONS\
md STATS\SESSION
goto aftersessioncheck

:cur_creativeleveldetected
set iscreative=1
rem @echo on
more /e +2 creativesharecode.txt >onlysharecode.txt
rem set /p sharecode=<onlysharecode.txt
REM for /f "tokens=*" %%A in ('findstr /C:"Load UGC via share code:" onlysharecode.txt') do (
    REM set "sharecode=%%A"
REM )
for /f "tokens=*" %%A in ('findstr /R "[0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]:[0-9][0-9]" onlysharecode.txt') do (
    set "sharecode=%%A"
)
set "sharecode=%sharecode:*share code: =%"
rem Thanks Copilot for helping me with this. I no longer like weird characters in UTF-8 BOM ...
rem set sharecode=%sharecode:~56%
set sharecode=%sharecode::= ZDEL%
md GetCreative
cd GetCreative
md %sharecode%
dir /ON /B >onlysharecode.txt
set /p sharecode=<onlysharecode.txt
cd ..
rd GetCreative /Q /S
if not exist MAPS\CREATIVE-%sharecode%.txt goto cur_aftercreativelastplayed
dir /ta MAPS\CREATIVE-%sharecode%.txt | find "CREATIVE-%sharecode%.txt" >getlvllastplay.txt
set /p addinfo=<getlvllastplay.txt
set addinfo=%addinfo:~0,17%
if not exist STATS\ALLTIME\UGC2MAP\%sharecode%.txt goto cur_aftercreativelastplayed
set /p statsmapname=<STATS\ALLTIME\UGC2MAP\%sharecode%.txt
set statsmapname=%statsmapname: =%
if not exist STATS\ALLTIME\ROUNDS\%statsmapname%\ goto cur_aftercreativelastplayed
set /p mapstatsqual=<STATS\ALLTIME\ROUNDS\%statsmapname%\qualifications.txt
set /p mapstatselim=<STATS\ALLTIME\ROUNDS\%statsmapname%\eliminations.txt

rem if %mapstatsqual%==0 set fractional=0 && goto aftermath_creativemap
rem if %mapstatselim%==0 set fractional=100 && goto aftermath_creativemap

:: 1. Calculate total matches (Denominator)
set /a totalmatches_cre=%mapstatsqual% + %mapstatselim%

:: 2. If total is 0, skip to prevent a crash (Division by Zero)
if %totalmatches_cre%==0 (
    rem echo Qualification Rate: 0.00%%
    goto cur_aftercreativelastplayed
)

:: 3. Multiply quals by 10000 and divide by total
set /a scaled=(%mapstatsqual% * 10000) / %totalmatches_cre%

:: 4. Extract whole and fractional parts
set /a whole=%scaled% / 100
set /a frac_raw=%scaled% %% 100

:: 5. Pad leading zero for the fractional part if needed
if %frac_raw% LSS 10 (
    set fractional=0%frac_raw%
) else (
    set fractional=%frac_raw%
)

rem echo Qualification Rate: %whole%.%fractional%%%
:aftermath_creativemap
set whole=%whole: =%
set fractional=%fractional: =%
set addinfo=%addinfo% QR %whole%.%fractional%P
:cur_aftercreativelastplayed
if exist MAPS\CREATIVE-%sharecode%.txt goto cur_loadsharecache
cls
echo %text.leveldb.lookup%: %sharecode% ... ^[----------^] 00
rem %ESC%[1;1
rem echo 
set lvlcode=%sharecode%
if defined dontperformlvllookup set mapname=%sharecode% && goto cur_displaycreativelevel
curl -q -A "%useragent%" https://api2.fallguysdb.info/api/creative/%lvlcode%.json>levelcodedown.txt
cls
echo %text.leveldb.powershell% ^[#####-----^] 50
start /wait /min conhost --headless cmd /c powershell -Command "& {Get-Content levelcodedown.txt | ConvertFrom-Json | ConvertTo-Json -Depth 10 | Out-File getlevelcode.txt}"
REM del getlevelcode.txt /q /f >NUL
REM start /min cmd /c DecodeLevel.bat
REM rem pause
REM :cur_waitforlevelextracted
REM if not exist getlevelcode.txt goto cur_waitforlevelextracted
find "title" getlevelcode.txt >outlevelcode.txt
if not %errorlevel%==0 goto cur_getcodefailed
more /e +3 outlevelcode.txt >outlevelcode2.txt
set /p levelname=<outlevelcode2.txt
set mapname=!levelname:~42,-2!
set completedcreativelevel=1
echo !mapname!>MAPS\CREATIVE-%sharecode%.txt
goto cur_displaycreativelevel

:cur_loadsharecache
set /p mapname=<MAPS\CREATIVE-%sharecode%.txt
set completedcreativelevel=1
goto cur_displaycreativelevel

:cur_getcodefailed
set mapname=%sharecode%
set completedcreativelevel=1
:cur_displaycreativelevel
set mapname=!mapname:\u0027='!
rem cls
echo %ESC%[1;1H%text.loadingmap_known% !mapname! (%sharecode%) ...
set gmncode=%sharecode%
set mapmsg=%text.loadingmap_known% !mapname! (%sharecode%) ...
goto cur_onlywaitformapload

:newingame
REM set byownqualcheck=0
REM set byglobqualcheck=0
REM set byglobelimcheck=0
REM set byglobtimercheck=0
set ingameline=0
set skipitelim=0
type nul>empty.sys
echo debug:
echo lines: %lines%
echo ingameline: %ingameline%
rem insert call command here
call :cur_gamerunning2
goto cur_returnnewingame
:cur_gamerunning2
if %qualified%==0 set text=%text.ingame.time%: %seconds%
if %qualified%==1 set text=%text.ingame.time%: %seconds% %text.ingame.qualifiedownprefix%: %qualifiedseconds%
set text=%text% %text.ingame.roundprefix%%currentround%: !mapname!
if %playersqualified% GTR 0 set text=%text% - %text.ingame.totalqualified%: %playersqualified%
if %playerseliminated% GTR 0 set text=%text% - %text.ingame.totaleliminated%: %playerseliminated%
if %usereliminated%==1 set text=%text% %text.ingame.owneliminated%
rem if %usereliminated%==1 echo eliminated
rem cls
echo %ESC%[1;1H%text%
rem echo ownqual: %byownqualcheck%, globqual: %byglobqualcheck%, globelim: %byglobelimcheck%, timer: %byglobtimercheck%
goto :EOF
:cur_newingametimecheck
set newseconds=
set /p newseconds=<seconds.sys
if not defined newseconds set newseconds=%seconds%
if %newseconds%==%seconds% goto cur_letitupdategen
set seconds=%newseconds%
set lastseconds=%seconds%
call :cur_gamerunning2
rem Hier muss noch ein Display generator sein, das die Ingame Stats anzeigt. Nach dem letzten Ingame-Befehlsblock, muss der ingameline wert aktualisiert werden.
:cur_returnnewingame
:cur_ingame2
findstr /R /N "^" "TEMP.gen" | find /C ":" >ingameline.sys
:cur_letitupdategen
more /e +%lines% "%logfile%" >TEMP.gen
set /p ingameline=<ingameline.sys
more /e +%ingameline% TEMP.gen >InGame.gen
fc InGame.gen empty.sys >NUL
if %errorlevel%==0 goto cur_newingametimecheck
rem New lines for processing found, so we´re processing those lines now!
if %qualified%==1 goto cur_afterqualifiedcheck2
find /i "ClientGameManager::HandleServerPlayerProgress PlayerId=%myplayerid% is succeeded=True" InGame.gen >NUL
if not %errorlevel%==0 goto cur_afterqualifiedcheck2
set qualified=1
set qualifiedseconds=%seconds%
REM set /a byownqualcheck=%byownqualcheck%+1
if %blockrewards%==1 call :cur_gamerunning2
set /a stats.qualified=%stats.qualified%+1
echo %stats.qualified% >stats.qualified.sys
start /min cmd /c stats_addqualify.bat
call :cur_gamerunning2
:cur_afterqualifiedcheck2
find /i "[ClientGameSession] NumPlayersAchievingObjective=" InGame.gen>qualifynumbers.sys
if not %errorlevel%==0 goto cur_aftercheckingqualificationnumbers2
tail -1 "%cd%\qualifynumbers.sys">"%cd%\qualifynumbers2.sys"
set /p lastqualify=<"%cd%\qualifynumbers2.sys"
set almostqualifynumber=%lastqualify:*ve=ve%
set playersqualified2=%almostqualifynumber:~3%
if %playersqualified2%==%lastplayersqualified% goto cur_aftercheckingqualificationnumbers2
set playersqualified=%playersqualified2%
set lastplayersqualified=%playersqualified%
rem set /a byglobqualcheck=%byglobqualcheck%+1
call :cur_gamerunning2
:cur_aftercheckingqualificationnumbers2
find /i "is succeeded=False" InGame.gen >elimplayers.sys
if not %errorlevel%==0 goto cur_aftercheckingeliminationnumbers233
for /f "usebackq" %%b in (`type elimplayers.sys ^| find "" /v /c`) do set elimnumber=%%b
set /a elimnumber=%elimnumber%-2
if %elimnumber% GTR 0 set playerseliminated2=%elimnumber%
:cur_aftercheckingeliminationnumbers23
if %usereliminated%==1 goto afteringameelimcheck2
find /i "Qualified: False" InGame.gen>NUL
if not %errorlevel%==0 goto afteringameelimcheck2
set usereliminated=1
if %blockrewards%==1 goto afteringameelimcheck2
set /a stats.eliminated=%stats.eliminated%+1
echo %stats.eliminated% >stats.eliminated.sys
start /min cmd /c stats_addelimination.bat
:afteringameelimcheck2
if %skipitelim%==1 goto cur_aftercheckingeliminationnumbers2
if %playerseliminated2%==0 goto cur_aftercheckingeliminationnumbers2
set /a playerseliminated=%playerseliminated%+%playerseliminated2%
rem set /a byglobelimcheck=%byglobelimcheck%+1
call :cur_gamerunning2
:cur_aftercheckingeliminationnumbers2
set skipitelim=0
rem Hier täten die Sekunden her kommen, aber wir werden die Sekunden nur MIST, nvm,
rem wir werden die Sekunden doppelt checken, falls es immernoch zu langsamerer PCs gibt ...
set newseconds=
set /p newseconds=<seconds.sys
if not defined newseconds set newseconds=%seconds%
if %newseconds%==%seconds% goto cur_aftercheckingseconds2
set seconds=%newseconds%
set lastseconds=%seconds%
rem set /a byglobtimercheck=%byglobtimercheck%+1
call :cur_gamerunning2
:cur_aftercheckingseconds2
:aftercheckingseconds2
find /i "[StateMainMenu] Loading scene MainMenu" InGame.gen >NUL
if %errorlevel%==0 goto cur_checkaddelimmainmenu
if not %isexplore%==1 goto afterexplorecheck2
find /i "[GameplaySpectatorUltimatePartyFlowViewModel] Matchmaking begins!" InGame.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
find /i "[MatchmakeWhileInGameHandler] Begin matchmaking..." InGame.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
rem Ich meine hier müssen wir keine 2te version vom goto machen
:afterexplorecheck2
find /i "[GameSession] Changing state from Playing to GameOver" InGame.gen >NUL
if not %errorlevel%==0 goto cur_ingame2
if not %playersqualified%==0 goto skipsurvivalmaptest2
find /C "is succeeded=True" TEMP.gen | find "-" >abuild.txt
rem Hier muss man TEMP.gen nehmen ...
set /p inl=<abuild.txt
set playersqualified=%inl:~-2%
set playersqualified=%playersqualified: =%
:skipsurvivalmaptest2
rem Hier ist die Runde beendet.
goto skipsurvivalmaptest

:cur_aftercheckingeliminationnumbers233
set skipitelim=1
goto cur_aftercheckingeliminationnumbers23

:lonelyingame
cls
call :cur_gamerunning_lonely
:cur_ingame_lonely
more /e +%lines% "%logfile%" >TEMP.gen
set newseconds=
set /p newseconds=<seconds.sys
if not defined newseconds set newseconds=%seconds%
if %newseconds%==%seconds% goto cur_aftercheckingseconds_lonely
set seconds=%newseconds%
set lastseconds=%seconds%
call :cur_gamerunning_lonely
:cur_aftercheckingseconds_lonely
:aftercheckingseconds_lonely
find /i "[StateMainMenu] Loading scene MainMenu" TEMP.gen >NUL
if %errorlevel%==0 goto cur_checkaddelimmainmenu
if not %isexplore%==1 goto afterexplorecheck_lonely
find /i "[GameplaySpectatorUltimatePartyFlowViewModel] Matchmaking begins!" TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
find /i "[MatchmakeWhileInGameHandler] Begin matchmaking..." TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitforexplorematchmaking
:afterexplorecheck_lonely
find /i "[GameSession] Changing state from Playing to GameOver" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_ingame_lonely
echo Round Over! && goto cur_ingame
:cur_gamerunning_lonely
rem cls
echo %ESC%[1;1H%text.ingame.time%: %seconds% %text.ingame.roundprefix%%currentround%: !mapname!
timeout 1 >NUL
goto :EOF

:cur_checkaddelimmainmenu
if %usereliminated%==1 goto cur_clsmainmenu
set /a stats.eliminated=%stats.eliminated%+1
echo %stats.eliminated% >stats.eliminated.sys
start /min cmd /c stats_addelimination.bat
goto cur_clsmainmenu

:cur_loginstatus
cls
color e
echo ^[                 ^] %text.start.connecting%
:cur_waitloginstep1
more /e +%lines% "%logfile%" >TEMP.gen
find "[EpicAccountsHelper] Starting EOS Login" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitloginstep1
cls
echo ^[#                ^] %text.start.loggingin%
:cur_waitloginstep2
more /e +%lines% "%logfile%" >TEMP.gen
find "Login complete: EOS_Success" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitloginstep2
cls
echo ^[##               ^] %text.start.loggingincatapult%
:cur_waitloginstep3
more /e +%lines% "%logfile%" >TEMP.gen
find "[EpicAccountsHelper] EOS Login Completed" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitloginstep3
cls
echo ^[###              ^] %text.start.checkeula%
:cur_waitloginstep4
more /e +%lines% "%logfile%" >TEMP.gen
find "[CatapultServicesManager] State changed from 'CheckingEula' to 'LoggingIn'" TEMP.gen >NUL
if not %errorlevel%==0 goto cur_waitloginstep4
cls
echo ^[####             ^] %text.start.loggingfg%
:cur_waitloginstep5
more /e +%lines% "%logfile%" >TEMP.gen
find "[GamefuelContentDownloader] Validating certificate, errors: None" TEMP.gen >NUL
if %errorlevel%==0 goto cur_waitloginstepcontentdownload
find "[CatapultServicesManager] State changed from 'LoggingIn' to 'ConnectingToGatewayServer'" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep5
goto cur_waitloginstep6wait

:cur_waitloginstepcontentdownload
cls
echo ^[#####            ^] %text.start.contentdl%
:cur_waitdownloadcontentupdate
more /e +%lines% "%logfile%" >TEMP.gen
find "[GamefuelContentDownloader] Download finished" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitdownloadcontentupdate
cls
echo %text.start.contentdldone%
:cur_waitloginstepspecial
more /e +%lines% "%logfile%" >TEMP.gen
find "[CatapultServicesManager] State changed from 'LoggingIn' to 'ConnectingToGatewayServer'" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstepspecial
:cur_waitloginstep6wait
cls
echo ^[######           ^] %text.start.connectgateway%
:cur_waitloginstep6
more /e +%lines% "%logfile%" >TEMP.gen
find "[CatapultServicesManager] State changed from 'ConnectingToGatewayServer' to 'Authenticating'" TEMP.gen >nul
if not %errorlevel%==0 goto cur_Waitloginstep6
cls
echo ^[#######          ^] %text.start.logginggateway%
:cur_waitloginstep7
more /e +%lines% "%logfile%" >TEMP.gen
find "[CatapultServicesManager] State changed from 'Authenticating' to 'LoadingGameServices'" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep7
cls
echo ^[########         ^] %text.start.loadgame%
:cur_waitloginstep8
more /e +%lines% "%logfile%" >TEMP.gen
find "[RewardService] Claim all rewards" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep8
cls
echo ^[#########        ^] %text.start.claimrewards%
:cur_waitloginstep9
more /e +%lines% "%logfile%" >TEMP.gen
find "[PlayerStats] [UpdateCache] Player stats updated" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep9
cls
echo ^[##########       ^] %text.start.claimrewards_done%
:cur_waitloginstep10
more /e +%lines% "%logfile%" >TEMP.gen
find "Received achievement from Catapult" TEMP.gen >nul
if %errorlevel%==0 goto cur_waitloginstep10special
find "[PlayerSeasonService] Refresh season in" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep10
goto cur_waitloginstep11wait

:cur_waitloginstep10special
cls
echo ^[##########       ^] %text.start.achivements%
:cur_waitloginstep11
more /e +%lines% "%logfile%" >TEMP.gen
find "[PlayerSeasonService] Refresh season in" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep11
:cur_waitloginstep11wait
cls
echo ^[###########      ^] %text.start.waitgameservices%
:cur_waitloginstep12
more /e +%lines% "%logfile%" >TEMP.gen
find "[CatapultServicesManager] State changed from 'LoadingGameServices' to 'Connected'" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep12
cls
echo ^[############     ^] %text.start.gameservices_done%
:cur_waitloginstep13
more /e +%lines% "%logfile%" >TEMP.gen
find "[CatapultServicesManager] Loading and parsing content:" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep13
cls
echo ^[#############    ^] %text.start.contentload%
:cur_waitloginstep14
more /e +%lines% "%logfile%" >TEMP.gen
find "[CatapultServicesManager] CMS data parsed successfully" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep14
cls
echo ^[##############   ^] %text.start.contentload_done%
:cur_waitloginstep15
more /e +%lines% "%logfile%" >TEMP.gen
find "[CATAPULT] Login Succeeded" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep15
cls
echo ^[###############  ^] %text.start.loggedincataput%
:cur_waitloginstep16
more /e +%lines% "%logfile%" >TEMP.gen
find "[PartyStateManager] Attempting to create core party after returning to main menu" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep16
cls
echo ^[################ ^] %text.start.createparty%
:cur_waitloginstep17
more /e +%lines% "%logfile%" >TEMP.gen
find "[PartyStateManager] Created core party" TEMP.gen >nul
if not %errorlevel%==0 goto cur_waitloginstep17
cls
echo Done! Updating log file ...
goto cur_resettemp