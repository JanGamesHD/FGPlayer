@echo off
:a
cls
set /p map=<MAPS\currentmap.sys
if exist MAPS\currentcreative.sys goto selector
if exist MAPS\currentcreativevanilla.sys goto selector
:s
del MAPS\currentcreative.sys /Q /F
cls
echo Enter new Map name for %map% or exit
set /p newmap=Map: 
if "%newmap%"=="exit" exit 
echo Wrinting...
echo %newmap%>MAPS\%map%.map
echo Done!
pause
echo 111
pause
goto a

:selector
set isit=0
if exist MAPS\currentcreative.sys set /p creativemap=<MAPS\currentcreative.sys
if exist MAPS\currentcreativevanilla.sys set /p creativemap=<MAPS\currentcreativevanilla.sys
if exist MAPS\currentcreativevanilla.sys set isit=1
if exist MAPS\currentcreative.sys set isit=0
cls
echo 1) Creative Map: %creativemap%
echo 2) Normal Map: %map%
echo 3) Exit
set /p opt=Opt: 
if %opt%==1 goto creative
if %opt%==2 goto s
if %opt%==3 exit
goto selector

:creative
set isit=0
rem del MAPS\currentcreative.sys /Q /F
if exist MAPS\currentcreativevanilla.sys set isit=1
echo Is Vanilla: %isit%
:returnval
cls
echo Enter new Map name for %creativemap%
if %isit%==1 echo TYP: Vanilla
if %isit%==0 echo TYP: Retro
echo Type x to change map variation
set /p newmap=Map: 
if "%newmap%"=="x" goto changeandreload
rem if exist MAPS\currentcreativevanilla.sys set isit=1
echo Wrinting...
if %isit%==0 echo %newmap%>MAPS\%creativemap%.map
if %isit%==1 echo %newmap%>MAPS\%creativemap%.mapvanilla
echo Done!
pause
echo 111
pause
goto a

:changeandreload
if %isit%==1 goto change20
if %isit%==0 goto change21
echo BOOM
pause
exit

:change20
set isit=0
goto returnval

:change21
set isit=1
goto returnval
