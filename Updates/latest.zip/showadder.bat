@echo off
:a
cls
echo Loading show...
if not exist "%cd%\selectedshow.sys" goto noshowfound
set /p show=<"%cd%\selectedshow.sys"
:t
echo Enter Max Player Count for Show: %show%
set /p playercount=Player Count: 
echo Writing...
echo %playercount% >FGPLAYER\SHOWSELECTOR\%show%.sys
echo Done!
pause
goto a

:noshowfound
cls
echo No Show found.
echo 1) Reload
echo 2) Manual
set /p opt=Opt: 
if %opt%==1 goto a
if %opt%==2 goto addman
goto noshowfound

:addman
cls
echo Enter Show Code Name.
set /p show=Show Codename: 
goto t