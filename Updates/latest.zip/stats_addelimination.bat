:stats_addelimination
if not %creativemap%==0 goto stats_addelimination_creative
if not exist STATS\ALLTIME\ROUNDS\%theunimap%\ call :stats_addstatsalltime
:after_addstatsalltime
rem insert check for this session
if not exist STATS\SESSION\ROUNDS\%theunimap%\ call :stats_addstatssession
:after_addstatssession
set /p statscurround=<STATS\ALLTIME\ROUNDS\%theunimap%\eliminations.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\ALLTIME\ROUNDS\%theunimap%\eliminations.txt
set /p statscurround=<STATS\ALLTIME\ROUNDS\%theunimap%\plays.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\ALLTIME\ROUNDS\%theunimap%\plays.txt
set /p statscurround=<STATS\SESSION\ROUNDS\%theunimap%\eliminations.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\SESSION\ROUNDS\%theunimap%\eliminations.txt
set /p statscurround=<STATS\SESSION\ROUNDS\%theunimap%\plays.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\SESSION\ROUNDS\%theunimap%\plays.txt
goto :EOF


:stats_addstatsalltime
md STATS\ALLTIME\ROUNDS\%theunimap%\
echo 0 >STATS\ALLTIME\ROUNDS\%theunimap%\plays.txt
echo 0 >STATS\ALLTIME\ROUNDS\%theunimap%\eliminations.txt
echo 0 >STATS\ALLTIME\ROUNDS\%theunimap%\qualifications.txt
goto :EOF

:stats_addelimination_creative
if not exist STATS\ALLTIME\ROUNDS\%themap%\ call :stats_addstatsalltime_creative
:after_addstatsalltime_creative
if not exist STATS\SESSION\ROUNDS\%themap%\ call :stats_addstatssession_creative
:after_addstatssession_creative
rem insert check for this session
set /p statscurround=<STATS\ALLTIME\ROUNDS\%themap%\eliminations.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\ALLTIME\ROUNDS\%themap%\eliminations.txt
set /p statscurround=<STATS\ALLTIME\ROUNDS\%themap%\plays.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\ALLTIME\ROUNDS\%themap%\plays.txt
set /p statscurround=<STATS\SESSION\ROUNDS\%themap%\eliminations.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\SESSION\ROUNDS\%themap%\eliminations.txt
set /p statscurround=<STATS\SESSION\ROUNDS\%themap%\plays.txt
set /a statscurround=%statscurround%+1
echo %statscurround% >STATS\SESSION\ROUNDS\%themap%\plays.txt
goto :EOF

:stats_addstatsalltime_creative
md STATS\ALLTIME\ROUNDS\%themap%\
echo 0 >STATS\ALLTIME\ROUNDS\%themap%\plays.txt
echo 0 >STATS\ALLTIME\ROUNDS\%themap%\eliminations.txt
echo 0 >STATS\ALLTIME\ROUNDS\%themap%\qualifications.txt
goto :EOF

:stats_addstatssession_creative
md STATS\SESSION\ROUNDS\%themap%\
echo 0 >STATS\SESSION\ROUNDS\%themap%\plays.txt
echo 0 >STATS\SESSION\ROUNDS\%themap%\eliminations.txt
echo 0 >STATS\SESSION\ROUNDS\%themap%\qualifications.txt
goto :EOF

:stats_addstatssession
md STATS\SESSION\ROUNDS\%theunimap%\
echo 0 >STATS\SESSION\ROUNDS\%theunimap%\plays.txt
echo 0 >STATS\SESSION\ROUNDS\%theunimap%\eliminations.txt
echo 0 >STATS\SESSION\ROUNDS\%theunimap%\qualifications.txt
goto :EOF