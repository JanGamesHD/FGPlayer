@echo off
:reload
del seconds.sys /Q /F
del quittimer.sys /Q /F
del startcount.sys /Q /F
echo Timer Ready! You can minimize this window.
set counter=0
:wfs
if exist quittimer.sys exit
if not exist startcount.sys goto wfs
:recount
cls
echo S: %counter%
if exist quittimer.sys exit
echo %counter% >seconds.sys
set /a counter=%counter%+1
timeout 1 >NUL
goto recount